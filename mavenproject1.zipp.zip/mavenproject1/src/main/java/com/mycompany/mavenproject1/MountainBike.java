package com.mycompany.mavenproject1;

import java.util.*;
import java.math.*;
import java.io.*;
import java.lang.*;

//Define the properties and features of the basic bike type plant
//This file is not intended for execution so there is no needf or a PSVM

//Interhirted class from the Parent/Base Class
//Base/super/parent/root class: BasicBike
//Inhertied/child class: MountainBike

//BasicBike is the base class || (partent class) || ((supper class) for all that )
class MountainBike extends BasicBike // MountainBike is child of BasicBike
{
    // public variables
    public int seatHeight;
    public boolean fullSuspension;
    public boolean flatProofTires;
    public int numOfGears;

    // protected cariables

    // private variables

    // Constructors #only one is used here, you can have multiple constructors if
    // you want to

    MountainBike(int SH, boolean FS, boolean FPT, int S, int nG, String C, String SF) 
    //SeatHeight, FullSuspension, FlatProofTires, Speed, Number of Gears, Color, Saftey Features
    {
        //Passing the base class parameters to the base class constructor
        //"Super" is a keyword
        //Make sure this is the first line in any inherited class constructor 
        super(S, nG, C, SF);
        this.seatHeight = SH;
        this.fullSuspension = FS;
        this.flatProofTires = FPT;
        this.numOfGears = nG;
    }

    // Methods

    // Getters and Setters

    // Behavior Methods

    // Polymorphism (run time) - this iherited class method OVERIDES the base class
    // method
    /*
     * (non-Javadoc)
     * 
     * @see BasicBike#getInfo()
     */
    /*
     * (non-Javadoc)
     * 
     * @see BasicBike#getInfo()
     */
    public String getInfo() {
        String msg;
        msg = "Bike info: 1/2: (Max Speed Setting " + maxSpeed + ", Num of Gears " + numOfGears + ", Frame Color "
                + paintColor + ", Saftey features " + safetyFeatures + "}\n";

        msg = msg + "Bike info 2/2: (Seat Height " + seatHeight + ", Full Suspension " + fullSuspension
                + ", Flat Proof Tires " + flatProofTires + "}\n";
        return msg;

    }

}// End class MountainBike
