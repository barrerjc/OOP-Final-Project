import com.mycompany.mavenproject1.EBike;
import com.mycompany.mavenproject1.MountainBike;
import com.mycompany.mavenproject1.RoadBike;
import com.mycompany.mavenproject1.RoadEBike;
import java.util.*;

import javax.swing.plaf.synth.SynthOptionPaneUI;

import java.math.*;
import java.io.*;
import java.lang.*;

// This is a class that withholds the Bike Shop itself
// This will illustrate an inventory system
public class BikeShopPro {
    public static void main(String[] args) {
        // We do all the global settings || Initializations here:
        // Global Variables
        // This is intended to capture the size limit of the shop floor
        final int MAX_INVENTORY_SIZE = 500;

        // Max limit for bikes of a certain type
        final int MAX_INVENTORY_SIZE_PER_TYPE = 100;

        // This is a settings variable for descriptive messages
        boolean verboseMode = false; // iff TRUE: || iff FALSE:

        // Create the backbone data structure (something that holds the data for the
        // bikes)
        // such that it is easy to add, delete, modify, search && list the contents of:
        BasicBike[] basicBikeArray; // Declares the array
        basicBikeArray = new BasicBike[MAX_INVENTORY_SIZE_PER_TYPE]; // Creating the array

        MountainBike[] mountainBikeArray; // Declares the array
        basicBikeArray = new MountainBike[MAX_INVENTORY_SIZE_PER_TYPE]; // Creating the array

        RoadBike[] RoadBikeArray; // Declares the array
        basicBikeArray = new RoadBike[MAX_INVENTORY_SIZE_PER_TYPE]; // Creating the array

        EBike[] EBikeArray; // Declares the array
        basicBikeArray = new EBike[MAX_INVENTORY_SIZE_PER_TYPE]; // Creating the array

        RoadEBike[] RoadEBikeArray; // Declares the array
        basicBikeArray = new RoadEBike[MAX_INVENTORY_SIZE_PER_TYPE]; // Creating the array

        // Initialize the basicBikeArray
        for (i = 0; i < MAX_INVENTORY_SIZE_PER_TYPE; i++) { // Similar objects being pulled from InheritanceDemo
            basicBikeArray[i] = new BasicBike(); // Pulling objects from BasicBike (Ln.43:49)

            mountainBikeArray[i] = new MountainBike(0, false, false, 0, 0, "", "");

            RoadBikeArray[i] = new RoadBike(0, 0, "", "", false);

            EBikeArray[i] = new EBike(0, "", 0, 0, 0.0, 0, false, false, 0, 0, "", "");

        }
        // List contents of basicBikeArrray i,e the entire inventory
        for (i = 0; i < MAX_INVENTORY_SIZE_PER_TYPE; i++) {
            basicBikeArray[i].getInfo(); // Pulling objects from BasicBike (Ln.107)
            System.out.println("Basic Bike slot #" + i + ":" + basicBikeArray[i].getInfo() + "\n");

            mountainBikeArray[i].getInfo(); // Pulling objects form mountainBike (Ln.58)
            System.out.println("Mountain Bike slot #" + i + ":" + mountainBikeArray[i].getInfo() + "\n");

            RoadBikeArray[i].getInfo(); // Pulling objects form RoadBike (Ln.35)
            System.out.println("Road Bike slot #" + i + ":" + RoadBikeArray[i].getInfo() + "\n");

            EBikeArray[i].getInfo(); // Pulling objects form EBike (Ln.39)
            System.out.println("EBike slot #" + i + ":" + EBikeArray[i].getInfo() + "\n");

            RoadEBikeArray[i].getInfo(); // Pulling objects form RoadBike (Ln.56)
            System.out.println("Road Bike slot #" + i + ":" + RoadEBikeArray[i].getInfo());

        }

    } // End PSVM

    // Methods that are called form within the main method
    // are to be placed

} // End - public class BikeShopPro
